const { Plugin, Notice } = require("obsidian");

class FileExplorerCheckboxes extends Plugin {
  checkedFiles = {};
  observer = null;
  styleEl = null;

  async onload() {
    await this.loadCheckedFiles();
    this.injectStyles();

    // Wait for layout to be ready before injecting checkboxes
    this.app.workspace.onLayoutReady(() => {
      this.injectCheckboxes();
      this.startObserver();
    });

    // Re-inject when layout changes (e.g. opening/closing folders)
    this.registerEvent(
      this.app.workspace.on("layout-change", () => {
        this.injectCheckboxes();
      })
    );

    // Add command to clear all checkboxes
    this.addCommand({
      id: "clear-all-checkboxes",
      name: "Clear all file explorer checkboxes",
      callback: () => {
        this.checkedFiles = {};
        this.saveCheckedFiles();
        this.injectCheckboxes();
        new Notice("All checkboxes cleared");
      },
    });

    // Add command to show progress
    this.addCommand({
      id: "show-checkbox-progress",
      name: "Show file explorer checkbox progress",
      callback: () => {
        const total = this.app.vault.getMarkdownFiles().length;
        const checked = Object.values(this.checkedFiles).filter(Boolean).length;
        new Notice(`Progress: ${checked} / ${total} notes checked`);
      },
    });
  }

  onunload() {
    if (this.observer) {
      this.observer.disconnect();
    }
    // Remove all injected checkboxes
    document.querySelectorAll(".fec-checkbox").forEach((el) => el.remove());
    if (this.styleEl) {
      this.styleEl.remove();
    }
  }

  injectStyles() {
    this.styleEl = document.createElement("style");
    this.styleEl.textContent = `
      .nav-file-title {
        display: flex !important;
        align-items: center !important;
      }
      .fec-checkbox {
        flex-shrink: 0;
        width: 14px;
        height: 14px;
        margin-right: 4px;
        margin-left: 0px;
        cursor: pointer;
        accent-color: var(--interactive-accent);
        opacity: 0.6;
        transition: opacity 0.15s ease;
      }
      .fec-checkbox:hover {
        opacity: 1;
      }
      .fec-checkbox:checked {
        opacity: 1;
      }
      .nav-file-title.fec-checked .nav-file-title-content {
        opacity: 0.45;
        text-decoration: line-through;
        text-decoration-color: var(--text-faint);
      }
    `;
    document.head.appendChild(this.styleEl);
  }

  injectCheckboxes() {
    const fileItems = document.querySelectorAll(".nav-file-title");

    fileItems.forEach((titleEl) => {
      // Skip if already has a checkbox
      if (titleEl.querySelector(".fec-checkbox")) {
        // Update checked state in case it changed
        const path = titleEl.dataset.path;
        if (path) {
          const cb = titleEl.querySelector(".fec-checkbox");
          cb.checked = !!this.checkedFiles[path];
          titleEl.classList.toggle("fec-checked", !!this.checkedFiles[path]);
        }
        return;
      }

      const path = titleEl.dataset.path;
      if (!path) return;

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.className = "fec-checkbox";
      checkbox.checked = !!this.checkedFiles[path];

      if (this.checkedFiles[path]) {
        titleEl.classList.add("fec-checked");
      }

      checkbox.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.checkedFiles[path] = !this.checkedFiles[path];
        checkbox.checked = this.checkedFiles[path];
        titleEl.classList.toggle("fec-checked", this.checkedFiles[path]);
        this.saveCheckedFiles();
      });

      // Insert checkbox as first child
      titleEl.insertBefore(checkbox, titleEl.firstChild);
    });
  }

  startObserver() {
    // Watch the file explorer for DOM changes (folder expand/collapse, new files)
    const explorerEl = document.querySelector(".nav-files-container");
    if (!explorerEl) return;

    this.observer = new MutationObserver(() => {
      this.injectCheckboxes();
    });

    this.observer.observe(explorerEl, {
      childList: true,
      subtree: true,
    });
  }

  async loadCheckedFiles() {
    const data = await this.loadData();
    this.checkedFiles = data || {};
  }

  async saveCheckedFiles() {
    await this.saveData(this.checkedFiles);
  }
}

module.exports = FileExplorerCheckboxes;
